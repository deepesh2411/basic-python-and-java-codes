
class Airtel implements PayTM           //implementing interface and overriding all its method
{
	int bal=0;
	public void recharge(long mob, int amt) {
		System.out.println("Rechage successful of "+amt+" on mobile no. :"+mob);
		bal=bal+amt;
	}
	public void denominations() {
		System.out.println("Top up plans for Airtel are: 10 50 100 200");
	}
	public void balEnquiry() {
		System.out.println("Current balanace amount : "+bal);
	}
}

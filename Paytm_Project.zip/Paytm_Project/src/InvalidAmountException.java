//exception class
public class InvalidAmountException extends Exception {
	
	InvalidAmountException(String str)
	{
		super(str);
	}
}

import java.util.Scanner;


class TestImplementation 
{
	public static int amt=0;
	static void recharge(PayTM obj) 
	{
		Scanner s1=new Scanner(System.in);
		System.out.println("Enter the Mobile No");
		long mob=s1.nextLong();
		String mobno=Long.toString(mob);
		
		if(mobno.length()!=10)         
		{
			s1.close();
			try {                                                            //exception for length only
				throw new InvalidMobileNumber("Invalid mobile no : mobile no. should be of 10 digit");
			}
			catch(InvalidMobileNumber imn){
				System.out.println(imn);	
			}
		}
		else
		{
			obj.denominations();
			System.out.println("enter the topup value :select from the list");
			amt=s1.nextInt();
			if(amt>500 || amt<10)
			{
				s1.close();
				try {
					throw new InvalidAmountException("Invalid amount selected");
				}
				catch(InvalidAmountException iae){
					System.out.println(iae);	
				}
			}
			else
			{
				obj.recharge(mob, amt);
				obj.balEnquiry();
			}
		}
		
		s1.close();
	}
}

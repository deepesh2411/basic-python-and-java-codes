import java.util.Scanner;

class TestPayTM
{
	public static void main(String [] args) 
	{
		TestImplementation testimplementationobj=new TestImplementation(); //creating obj of TestImplementation class
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the service provider");          //input from user
		String sp=s.next();
		
		if(sp.equalsIgnoreCase("Airtel"))
		{
			PayTM obj=new Airtel();
			TestImplementation.recharge(obj);                    //we can use class name to call the static method
			//testimplementationobj.recharge(obj);				 //we can use obj of the class to call the static method
			
		}
		else if(sp.equalsIgnoreCase("Vodafone"))
		{
			PayTM obj=new Vodafone();
			testimplementationobj.recharge(obj);           // for vodafone using obj to call the method
		}
		else if(sp.equalsIgnoreCase("Idea"))
		{
			PayTM obj=new Idea();
			TestImplementation.recharge(obj);
		}
		else if(sp.equalsIgnoreCase("Jio"))
		{
			PayTM obj=new Jio();
			TestImplementation.recharge(obj);
		}
		else {
			System.out.println("service provider unavailable , please select from (Airtel, Vodafone, Idea, Jio)");
		}
		s.close();
	}
}

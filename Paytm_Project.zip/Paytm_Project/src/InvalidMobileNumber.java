//exception class
public class InvalidMobileNumber extends Exception{
	
	InvalidMobileNumber(String str)
	{
		super(str);
	}
}

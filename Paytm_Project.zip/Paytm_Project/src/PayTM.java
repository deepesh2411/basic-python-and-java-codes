interface PayTM
	{
		void recharge(long mob,int amt);
		void denominations();
		void balEnquiry();
	}

public class Demo {

	public static void main(String[] args) {
		
		int tNo;int NoofTicket;
		String cusName="";String TrainName="";
		
		//object creation of Railway ticket reservation
		RailwayReservation objRailReservation=new RailwayReservation("train","ashok","rajdhani",2,"AC2");
		
		//calling methods of RailwayReservation class and printing values 
		String TckCategory=objRailReservation.getCategory();
		
		tNo=objRailReservation.getTransectionNumber();
		System.out.println("Transaction Number  : "+tNo);

		System.out.println("Ticket Category     : "+TckCategory);

		cusName=objRailReservation.getCustomerName();
		System.out.println("Customer Name       : "+cusName);

		TrainName=objRailReservation.getTrainName();
		System.out.println("Train Name          : "+TrainName);

		NoofTicket=objRailReservation.getNumberOfTickets();
		System.out.println("Number of Tickets   : "+NoofTicket);

		objRailReservation.calulateAmount();                         //TOTAL AMOUNT
		
		System.out.println("");
		
		//object creation of Air ticket reservation
		AirTicketReservation objAirTicketReservation=new AirTicketReservation("flight","anjana","airIndia",3,"economy");
		
		//calling methods of AirTicketReservation class and printing values 
		String TckCategory2=objAirTicketReservation.getCategory();
		
		tNo=objAirTicketReservation.getTransectionNumber();
		System.out.println("Transaction Number  : "+tNo);


		System.out.println("Ticket Category     : "+TckCategory2);

		cusName=objAirTicketReservation.getCustomerName();
		System.out.println("Customer Name       : "+cusName);

		TrainName=objAirTicketReservation.getFlightName();
		System.out.println("Flight Name         : "+TrainName);

		NoofTicket=objAirTicketReservation.getNumberOfTickets();
		System.out.println("Number of Tickets   : "+NoofTicket);

		objAirTicketReservation.calulateAmount();
		
		
		System.out.println("");  //new line 
		
		AirTicketReservation objAirTicketReservation1=new AirTicketReservation("flight","deepesh","etihad",3,"business");
		
		String TckCategory3=objAirTicketReservation1.getCategory();
		
		tNo=objAirTicketReservation1.getTransectionNumber();
		System.out.println("Transaction Number  : "+tNo);


		System.out.println("Ticket Category     : "+TckCategory3);

		cusName=objAirTicketReservation1.getCustomerName();
		System.out.println("Customer Name       : "+cusName);

		TrainName=objAirTicketReservation1.getFlightName();
		System.out.println("Flight Name         : "+TrainName);

		NoofTicket=objAirTicketReservation1.getNumberOfTickets();
		System.out.println("Number of Tickets   : "+NoofTicket);

		objAirTicketReservation1.calulateAmount();
	}

}


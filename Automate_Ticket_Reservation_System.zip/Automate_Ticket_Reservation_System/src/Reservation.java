public class Reservation {
	
	private String category;
	private static int transectionNumber;
	private String customerName;
	public String WRONGcategory="wrong choice";
	
	public Reservation(String category, String customerName)  //initializing instance variable using constructor with parameter
	{
		this.category=category;
		this.customerName=customerName;
		transectionNumber=transectionNumber+1;
	}
	
	int getTransectionNumber() 
	{	
		return transectionNumber;
	}
	
	public String getCategory()
	{	
		if(validateCategory())       //if validate category return ture then if block executed else else block executed
		{
			return category;
		}
		else
			return WRONGcategory;
	}
	
	public String getCustomerName() 
	{	
		return customerName;
	}
	
	public boolean validateCategory() 
	{
		if(category.equalsIgnoreCase("train"))
		{
			return true;
		}
		else if( category.equalsIgnoreCase("flight"))
		{
			return true;
		}
		else 
			return false;
	}

}

public class AirTicketReservation extends Reservation{
	int amount;
	private String flightName;
	private int numberOfTickets;
	private String bookingClass;
	
	public AirTicketReservation(String category,String customerName,String flightName,int numberOfTickets,String bookingClass)
	{
		super(category,customerName);
		this.flightName=flightName;
		this.numberOfTickets=numberOfTickets;
		this.bookingClass=bookingClass;
	}
	
	public String getFlightName() 
	{
		return flightName;
	}
	
	public int getNumberOfTickets()
	{
		return numberOfTickets;	
	}
	
	public void calulateAmount()
	{
		if (bookingClass.equalsIgnoreCase("business"))
		{
			amount=numberOfTickets * 4500;
			System.out.println("Total amount        : "+amount);
		}
		else if(bookingClass.equalsIgnoreCase("economy"))
		{
			amount=numberOfTickets * 3500;
			System.out.println("Total amount        : "+amount);
		}
	}

}

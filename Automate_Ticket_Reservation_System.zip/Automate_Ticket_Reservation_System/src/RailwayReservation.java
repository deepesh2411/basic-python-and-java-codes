public class RailwayReservation extends Reservation {
	int amount;
	private String trainName;
	private int numberOfTickets;
	private String bookingClass;
	
	public RailwayReservation(String category,String customerName,String trainName,int numberOfTickets,String bookingClass)
	{
		super(category,customerName);
		this.trainName=trainName;
		this.numberOfTickets=numberOfTickets;
		this.bookingClass=bookingClass;
	}
	
	public String getTrainName() 
	{	
		return trainName;	
	}
	
	public int getNumberOfTickets()
	{	
		return numberOfTickets;	
	}
	
	public void calulateAmount()
	{
		if (bookingClass.equalsIgnoreCase("AC1"))
		{
			amount=numberOfTickets * 1500;
			System.out.println("Total amount        : "+amount);
		}
		else if(bookingClass.equalsIgnoreCase("AC2"))
		{
			amount=numberOfTickets * 1100;
			System.out.println("Total amount        : "+amount);
		}
		else if(bookingClass.equalsIgnoreCase("AC3"))
		{
			amount=numberOfTickets * 700;
			System.out.println("Total amount        : "+amount);
		}
	}
}

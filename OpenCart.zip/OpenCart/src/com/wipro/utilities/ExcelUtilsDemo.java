package com.wipro.utilities;

import java.io.IOException;

public class ExcelUtilsDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String projectPath=System.getProperty("user.dir");
		new ExcelUtils(projectPath+"/Resources/testdata//testData.xlsx", "sheet1");
		
		ExcelUtils.getRowCount();           //excel.getRowCount();  but static method call in static by using class name
		ExcelUtils.getColCount();
		//ExcelUtils.getCellDataNumber(1,0);
		ExcelUtils.getCellDataString(0,0);
	}

}

package com.wipro.utilities;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	static String projectPath;
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	public ExcelUtils(String excelPath,String sheetName) throws IOException
	{
		projectPath=System.getProperty("user.dir");
		//workbook= new XSSFWorkbook(projectPath+"/Resources/testdata//testData.xlsx");
		workbook= new XSSFWorkbook(excelPath);
		sheet=workbook.getSheet(sheetName);
	}
	
	
	public static int getRowCount() throws IOException {

		int rowCount=sheet.getPhysicalNumberOfRows();	
		System.out.println("no of rows"+rowCount);
		return rowCount;
	}
	
	public static int getColCount() throws IOException {

		int colCount=sheet.getRow(0).getPhysicalNumberOfCells();	
		System.out.println("no of cols"+colCount);
		return colCount;
	}
	
	
	public static String getCellDataString(int rowNum,int colNum) throws IOException {
	
		String cellData=sheet.getRow(rowNum).getCell(colNum).getStringCellValue();
		//System.out.println("cell data "+cellData);
		return cellData;
	}
	
	public static double getCellDataNumber(int rowNum,int colNum) throws IOException {

		double cellData=sheet.getRow(rowNum).getCell(colNum).getNumericCellValue();
		//System.out.println("cell data "+cellData);
		return cellData;
	}
	
	public static Object[][] testData(String excelPath,String sheetName) throws IOException
	{
		//ExcelUtils excel=
		new ExcelUtils(excelPath,sheetName);
		int rowCount=ExcelUtils.getRowCount();           //excel.getRowCount();  but static method call in static by using class name
		int colCount=ExcelUtils.getColCount();
		
		Object data[][]=new Object[rowCount-1][colCount];
		
		for(int i=1;i<rowCount;i++)
		{
			for(int j=0;j<colCount;j++)
			{
				String cellData=ExcelUtils.getCellDataString(i,j);
				//System.out.print(cellData+" | ");
				data[i-1][j]=cellData;
			}
			//System.out.println();
		}
		return data; 
	}
}

package com.wipro.testcases;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class ExcelGenerate {
	static String projectPath;
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException  {
		projectPath=System.getProperty("user.dir");
		File xmlFile=new File(projectPath+"\\test-output\\testng-results.xml");
		
		DocumentBuilderFactory fact=DocumentBuilderFactory.newInstance();
		DocumentBuilder build=fact.newDocumentBuilder();
		Document doc=build.parse(xmlFile);
		doc.getDocumentElement().normalize();
		
		
		XSSFWorkbook workbook= new XSSFWorkbook();
		NodeList testList=doc.getElementsByTagName("test");
		
		for(int i=0;i<testList.getLength();i++)
		{
			int r=0;
			Node testNode=testList.item(i);
			String testName=((Element)testNode).getAttribute("name");
			XSSFSheet sheet=workbook.createSheet(testName);
			NodeList classList=((Element)testNode).getElementsByTagName("class");
			
			for(int j=0;j<classList.getLength();j++)
			{
				Node classNode=classList.item(j);
				String className=((Element)classNode).getAttribute("name");
				NodeList testMethodList=((Element)classNode).getElementsByTagName("test-method");
				
				for(int k=0;k<testMethodList.getLength();k++)
				{
					Node testMethodNode=testMethodList.item(k);
					String testMethodName=((Element)testMethodNode).getAttribute("name");
					String testMethodStatus=((Element)testMethodNode).getAttribute("status");
					
					XSSFRow row=sheet.createRow(r++);
					XSSFCell cell=row.createCell(0);
					cell.setCellValue(className+" "+testMethodName);
					
					XSSFCell cell1=row.createCell(1);
					cell1.setCellValue(testMethodStatus);
					
					XSSFCell cellExp;//=row.createCell(1);
					String expMsg;
					if("fail".equalsIgnoreCase(testMethodStatus))
					{
						NodeList expList=((Element)testMethodNode).getElementsByTagName("exception");
						Node expNode=expList.item(0);
						expMsg=((Element)expNode).getAttribute("class"); 
						
						cellExp=row.createCell(2);
						cellExp.setCellValue(expMsg);
					}
					else
					{
						String testSignature=((Element)testMethodNode).getAttribute("signature");
						cellExp=row.createCell(3);
						cellExp.setCellValue(testSignature);
					}
					
				}
			}
		}
		FileOutputStream fout=new FileOutputStream(projectPath+"\\Resources\\runner\\report.xlsx");
		workbook.write(fout);
		fout.close();
		workbook.close();
		System.out.println("report generated");
		
	}

}

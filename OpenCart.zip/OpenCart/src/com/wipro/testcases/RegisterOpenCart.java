package com.wipro.testcases;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.wipro.utilities.ExcelUtils;
import com.wipro.utilities.LoginTest_Properties;

public class RegisterOpenCart {
	
	WebDriver driver2;
	String projectPath=System.getProperty("user.dir");
	@BeforeClass
    public void beforeClass() throws FileNotFoundException, IOException {
	  	driver2= new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DE20094713\\Downloads\\deepesh\\OpenCart\\Resources\\driverfiles\\chromedriver.exe");
		driver2.manage().window().maximize();
		
		//to get the url from the config file
		LoginTest_Properties objprop2=new LoginTest_Properties();   //object creaction of LoginTest_Properties class
		String str=objprop2.Login_Property();        			    //calling method of LoginTest_Properties using ref variable
		driver2.get(str);
    }
	
	@Test(dataProvider="testdata2")   //to take data from the  the dataProvider 
	public void test1(String firstName,String lastname,String email,String telephone,String password,String confirmPassword) throws InterruptedException, IOException
	{
		System.out.println(firstName+"  "+password);
		WebElement link,searchBox;
		link=driver2.findElement(By.linkText("My Account"));
		link.click();
		try{Thread.sleep(2000);}
		catch(Exception e){}
		link=driver2.findElement(By.linkText("Register"));
		link.click();
		Thread.sleep(2000);
		searchBox=driver2.findElement(By.id("input-firstname"));
		searchBox.sendKeys(firstName);
		searchBox=driver2.findElement(By.id("input-lastname"));
		searchBox.sendKeys(lastname);
		searchBox=driver2.findElement(By.id("input-email"));
		searchBox.sendKeys(email);
		searchBox=driver2.findElement(By.id("input-telephone"));
		searchBox.sendKeys(telephone);
		searchBox=driver2.findElement(By.id("input-password"));
		searchBox.sendKeys(password);
		searchBox=driver2.findElement(By.id("input-confirm"));
		searchBox.sendKeys(confirmPassword);
		
		searchBox=driver2.findElement(By.name("newsletter"));
		searchBox.click();
		searchBox=driver2.findElement(By.name("agree"));
		searchBox.click();
		Thread.sleep(5000);
		searchBox.submit();
		Thread.sleep(5000);
		
		//to take screenshots
		Date d = new Date();
		TakesScreenshot ts=(TakesScreenshot)driver2;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File(projectPath+"\\Resources\\Screenshots\\"+"register"+d.toString().replace(":", "_")+".png"));
		Thread.sleep(2000);

		//writing on text file
		FileWriter fw=new FileWriter("resources//config//logFile.txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		String st=driver2.findElement(By.xpath("//*[@id='content']/p[1]")).getText();
		bw.write("\n"+st);
		Thread.sleep(5000);

		//click on logout
		link=driver2.findElement(By.linkText("Logout"));
		link.click();
		Thread.sleep(2000);
		
		String st1=driver2.findElement(By.xpath("//*[@id='content']/p[1]")).getText();
		bw.write("\n"+st1);
		bw.close();
		Thread.sleep(5000);
	}

	@DataProvider(name="testdata2")
	public Object[][] getData() throws IOException
	{
		String projectPath=System.getProperty("user.dir");
		Object data[][]=ExcelUtils.testData(projectPath+"/Resources/testdata//testData.xlsx", "sheet2");
		return data;            //calling static testData from other package by className 
	}
	
	
	@AfterClass
    public void afterClass() throws IOException {
		driver2.quit();
    }
}

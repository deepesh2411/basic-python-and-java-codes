package com.wipro.testcases;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.wipro.utilities.ExcelUtils;
import com.wipro.utilities.LoginTest_Properties;

public class AddToCart {
	
	WebDriver driver;WebElement link1,searchBox1;
	String projectPath=System.getProperty("user.dir");
	@BeforeClass
    public void beforeClass() throws FileNotFoundException, IOException, InterruptedException {
	  	driver= new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DE20094713\\Downloads\\deepesh\\OpenCart\\Resources\\driverfiles\\chromedriver.exe");
		driver.manage().window().maximize();
		//to get the url from the config file
		LoginTest_Properties objprop2=new LoginTest_Properties();   //object creaction of LoginTest_Properties class
		String str=objprop2.Login_Property();        			    //calling method of LoginTest_Properties using ref variable
		driver.get(str);
	
    }

	@Test(priority=0,dataProvider="testdata2")   //to test the dataProvider 
	public void addToCart1(String username,String password) throws InterruptedException, IOException
	{
		
		FileWriter fw=new FileWriter("resources//config//logFile.txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		//System.out.println(username+"  "+password);
		
		link1=driver.findElement(By.linkText("My Account"));
		link1.click();
		Thread.sleep(2000);
		link1=driver.findElement(By.linkText("Login"));
		link1.click();
		Thread.sleep(2000);
		searchBox1=driver.findElement(By.id("input-email"));
		searchBox1.sendKeys(username);                  //values from excel
		searchBox1=driver.findElement(By.id("input-password"));
		searchBox1.sendKeys(password);					//values from excel
		Thread.sleep(2000);
		searchBox1.submit();
		Thread.sleep(5000);
		
		link1=driver.findElement(By.xpath("//*[text()='Components']"));
		link1.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
		Thread.sleep(2000);
		
		String st1=driver.findElement(By.xpath("//*[text()='Apple Cinema 30\"']")).getText();
		bw.write("\n"+st1);
		String st2=driver.findElement(By.xpath("//*[@class='price-new']")).getText();
		bw.write("\n"+st2);
		
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[2]/button[1]/span")).click();
		Thread.sleep(2000);
		
		//to take screenshots
		Date d = new Date();
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File(projectPath+"\\Resources\\Screenshots\\"+d.toString().replace(":", "_")+".png"));
		Thread.sleep(2000);
		bw.close();
		fw.close();
		Thread.sleep(2000);
	}
	
	@Test(priority=1,dataProvider="testdata3")
	public void addToCart2(String s1,String s2) throws InterruptedException
	{
		
		driver.findElement(By.xpath("//*[@id=\"input-option223\"]/div[1]/label/input")).click();
		//click on logout
		//link1=driver.findElement(By.linkText("Logout"));
		//link1.click();
		Thread.sleep(2000);
		searchBox1=driver.findElement(By.id("input-option208"));
		searchBox1.clear();
		searchBox1.sendKeys(s1);
		searchBox1=driver.findElement(By.id("input-option209"));
		searchBox1.clear();
		searchBox1.sendKeys(s2);
		
		//selecting from dropdown 
		WebElement sortby=driver.findElement(By.id("input-option217"));
		Select dropdown=new Select(sortby);
		dropdown.selectByValue("3");
		Thread.sleep(2000);
		
		//upload a img file
		//driver.findElement(By.id("button-upload222")).sendKeys("D:\\download.png");
		//((JavascriptExecutor)driver).executeScript("document.getElementById('button-upload222').value='c://aaaa.jpg'");
		//Thread.sleep(2000);
		searchBox1=driver.findElement(By.id("input-quantity"));
		searchBox1.clear();
		searchBox1.sendKeys("1");
		Thread.sleep(2000);
		driver.findElement(By.id("button-cart")).click();
		//String st=driver.findElement(By.xpath("//*[@id='content']/p[1]")).getText();
		//bw.write("\n"+st);
		Thread.sleep(10000);
	}
	
	
	
	
	@DataProvider(name="testdata2")
	public Object[][] getData() throws IOException
	{
		
		Object data[][]=ExcelUtils.testData(projectPath+"/Resources/testdata//testData.xlsx", "sheet1");
		return data;            //calling static testData from other package by className 
	}
	
	
	
	@DataProvider(name="testdata3")
	public Object[][] getData3() throws IOException
	{
		Object data[][]=ExcelUtils.testData(projectPath+"/Resources/testdata//testData.xlsx", "sheet3");
		return data; 
	}
	
	@AfterClass
    public void afterClass() throws IOException {
		driver.quit();
    }
    
}

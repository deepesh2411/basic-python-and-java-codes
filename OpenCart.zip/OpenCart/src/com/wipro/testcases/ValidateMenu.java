package com.wipro.testcases;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.wipro.utilities.ExcelUtils;
import com.wipro.utilities.LoginTest_Properties;

public class ValidateMenu {
	
	WebDriver driver;
	String projectPath=System.getProperty("user.dir");
	//static int linksCount = 0;
	
	@BeforeClass
    public void beforeClass() throws FileNotFoundException, IOException {
	  	driver= new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DE20094713\\Downloads\\deepesh\\OpenCart\\Resources\\driverfiles\\chromedriver.exe");
		driver.manage().window().maximize();
		
		//to get the url from the config file
		LoginTest_Properties objprop2=new LoginTest_Properties();   //object creaction of LoginTest_Properties class
		String str=objprop2.Login_Property();         //calling method of LoginTest_Properties using ref variable
		driver.get(str);
    }
	
	@Test(dataProvider="testdata1")   //to test the dataProvider 
	public void test1(String username,String password) throws InterruptedException, IOException
	{
		//writing on text file
		FileWriter fw=new FileWriter("resources//config//logFile.txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		System.out.println(username+"  "+password);
		WebElement link1,searchBox1;
		link1=driver.findElement(By.linkText("My Account"));
		link1.click();
		Thread.sleep(2000);
		link1=driver.findElement(By.linkText("Login"));
		link1.click();
		Thread.sleep(2000);
		searchBox1=driver.findElement(By.id("input-email"));
		searchBox1.sendKeys(username);                  //values from excel
		searchBox1=driver.findElement(By.id("input-password"));
		searchBox1.sendKeys(password);					//values from excel
		Thread.sleep(2000);
		searchBox1.submit();
		Thread.sleep(5000);
		
		//Menu count number
		List<WebElement> links = driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul")).findElements(By.xpath("./li"));
		int linksCount =links.size();
		System.out.println("no of links:" +links.size());
		String menuCount=Integer.toString(linksCount);
		bw.write("\n"+"Total no of links in menu : "+menuCount);
		
		//clicking on the links
		List<WebElement> links1 = driver.findElements(By.xpath("//*[@class=\"dropdown\" ]"));
		ListIterator<WebElement> itr=links1.listIterator();
		while(itr.hasNext())
		{
			WebElement web=itr.next();
			web.click(); 
			Thread.sleep(3000);
		}
		
		Date d = new Date();
		TakesScreenshot ts=(TakesScreenshot)driver;
		for(int i=4;i<8;i++)
		{
			driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li["+i+"]")).click();
			Thread.sleep(2000);
			File source=ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File(projectPath+"\\Resources\\Screenshots\\"+i+d.toString().replace(":", "_")+i+".png"));
			driver.navigate().back();
		}
		
		//click on logout
		link1=driver.findElement(By.linkText("My Account"));
		link1.click();
		link1=driver.findElement(By.linkText("Logout"));
		link1.click();
		Thread.sleep(2000);

		//writing on text file
		String st=driver.findElement(By.xpath("//*[@id='content']/p[1]")).getText();
		bw.write("\n"+st);
		bw.close();
		Thread.sleep(5000);
	}
	
	@DataProvider(name="testdata1")
	public Object[][] getData() throws IOException
	{
		
		Object data[][]=ExcelUtils.testData(projectPath+"/Resources/testdata//testData.xlsx", "sheet1");
		return data;            //calling static testData from other package by className 
	}
	
	@AfterClass
    public void afterClass() throws IOException {
		driver.quit();
    }
	
	
}

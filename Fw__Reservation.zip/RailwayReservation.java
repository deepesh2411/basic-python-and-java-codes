class RailwayReservation extends Reservation{

	private int numberOfTickets;
	private String trainName;
	private String bookingClass;

	public RailwayReservation(String category,String customerName,String trainName,int numberOfTickets,String bookingClass){
	super(category,customerName);
	this.trainName=trainName;
	this.numberOfTickets=numberOfTickets;
	this.bookingClass=bookingClass;
	}
	
	public String getTrainName(){
		return this.trainName;
	}
	
	public int getNumberOfTickets(){
		return this.numberOfTickets;
	}
	
	public void calculateAmount(){
		int ticketamount=0;
		int amount=0;
		
		if(this.bookingClass.equalsIgnoreCase("AC1")){
			ticketamount=1500;
		}
		else if(this.bookingClass.equalsIgnoreCase("AC2")){
			ticketamount=1100;
		}
		else if(this.bookingClass.equalsIgnoreCase("AC3")){
			ticketamount=700;
		}
		amount=numberOfTickets*ticketamount;
		System.out.println("\t amount\t\t\t\t\t: "+amount);
	}
	
	
	
	
}
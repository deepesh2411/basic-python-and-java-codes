class Demo{
	
	public static void main(String[] args){
		
		RailwayReservation objRailReservation = new RailwayReservation("train","ashok","rajdhani",2,"AC2");
		AirTicketReservation objAirTicketReservation = new AirTicketReservation("flight","anjana","airINDIA",3,"economy");
		
		System.out.println("Rail");
		System.out.println("\t Transaction Number\t\t\t: " +objRailReservation.getTransectionNumber());
		System.out.println("\t Ticket Category\t\t\t: " +objRailReservation.getCategory());
		System.out.println("\t Customer Name\t\t\t\t: " +objRailReservation.getCustomerName());
		System.out.println("\t Train Name\t\t\t\t: " +objRailReservation.getTrainName());
		System.out.println("\t Number of Tickets\t\t\t: " +objRailReservation.getNumberOfTickets());
		
		objRailReservation.calculateAmount();
		
		System.out.println("Flight");
		System.out.println("\t Transaction Number\t\t\t: " +objAirTicketReservation.getTransectionNumber());
		System.out.println("\t Ticket Category\t\t\t: " +objAirTicketReservation.getCategory());
		System.out.println("\t Customer Name\t\t\t\t: " +objAirTicketReservation.getCustomerName());
		System.out.println("\t Train Name\t\t\t\t: " +objAirTicketReservation.getFlightName());
		System.out.println("\t Number of Tickets\t\t\t: " +objAirTicketReservation.getNumberOfTickets());
		
		objAirTicketReservation.calculateAmount();
		
		
	}
}
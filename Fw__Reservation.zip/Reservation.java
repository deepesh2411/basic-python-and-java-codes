class Reservation{

	private static int bookingTransactionNumber=0;
	private  int transectionNumber;
	private String category;
	private String customerName;

	public  Reservation(String category,String customerName){
	this.category=category;
	this.customerName=customerName;
	}
	
	public int getTransectionNumber(){
		bookingTransactionNumber+=1;
		transectionNumber=bookingTransactionNumber;
		return this.transectionNumber;
	}
	
	public String getCategory(){
		return this.category;
	}
	
	public String getCustomerName(){
		return this.customerName;
	}
	
	public boolean validateCategory(){
		boolean validateCategory=false;
		if(getCategory().equalsIgnoreCase("train")|| getCategory().equalsIgnoreCase("flight")){
			validateCategory=true;
		}
		return validateCategory;
	}
	
	
}
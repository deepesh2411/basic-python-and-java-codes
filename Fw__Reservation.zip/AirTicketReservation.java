class AirTicketReservation extends Reservation{

	private int numberOfTickets;
	private String flightName;
	private String bookingClass;

	public AirTicketReservation(String category,String customerName,String flightName,int numberOfTickets,String bookingClass){
	super(category,customerName);
	this.flightName=flightName;
	this.numberOfTickets=numberOfTickets;
	this.bookingClass=bookingClass;
	}
	
	public String getFlightName(){
		return this.flightName;
	}
	
	public int getNumberOfTickets(){
		return this.numberOfTickets;
	}
	
	public void calculateAmount(){
		int ticketamount=0;
		int amount=0;
		
		if(this.bookingClass.equalsIgnoreCase("business")){
			ticketamount=4500;
		}
		else if(this.bookingClass.equalsIgnoreCase("economy")){
			ticketamount=3500;
		}
		
		amount=getNumberOfTickets()*ticketamount;
		System.out.println("\t amount\t\t\t\t\t: "+amount);
	}
	
	
	
	
}